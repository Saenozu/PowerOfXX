#POX{SHA1(api�Լ��̸�)}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_VAL (100)
int whoami(const char*, const char*);
void start(const char*, const char*);

int whoami(const char* first, const char* second, int len)
{
    int ret = -1;
    __asm
    {
        MOV ESI, [first]
        MOV EDI, [second]
    _loop:
        MOV DH, BYTE PTR[ESI]
        MOV DL, BYTE PTR[EDI]
        CMP DH, DL
        JE equal
        JA dest2
        JB dest3
    equal:
        INC ESI
        INC EDI
        CMP DH, 0x00
        JE dest1
        JMP _loop
    }
dest1:
    return 0;
dest2: 
    return 1;
dest3:
    return -1;
}

void start(const char* first, const char* second)
{
    int first_len  = strlen(first);
    int second_len = strlen(second);

    if (first_len == second_len)
    {
        int tmp = first_len;
        printf("Can you guess who am I?\n");
        switch (whoami(first, second, tmp))
        {
        case 0:
            printf("0");
            break;
        case 1:
            printf("1");
            break;
        case -1:
            printf("-1");
            break;
        }
    }
}

int main()
{    
    char a[MAX_VAL] = "\x00";
    char b[MAX_VAL] = "\x00";
    scanf_s("%s", a, MAX_VAL);
    scanf_s("%s", b, MAX_VAL);
    start(a,b);
}
