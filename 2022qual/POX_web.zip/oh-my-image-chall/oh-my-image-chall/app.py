import os
import json
import redis
import hashlib
from flask import Flask, session, request, render_template, redirect
from flask_session import Session
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = os.urandom(32)

redis_server = redis.from_url('redis://db:6379')

app.config['SESSION_PERMANENT'] = False

app.config['SESSION_TYPE'] = 'redis'
app.config['SESSION_USE_SIGNER'] = False
app.config['SESSION_REDIS'] = redis_server

server_session = Session(app)


def get_images_info():
    try:
        raw = redis_server.get(name=session['nickname'])
        image_infos = json.loads(raw)
    except:
        image_infos = {}
    
    return image_infos
    

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'GET':
        if 'nickname' in session:
            return render_template('main.html',
                                    name        = session['nickname'],
                                    image_infos = get_images_info(),
                                    enumerate   = enumerate)
    elif request.method == 'POST':
        nickname = request.form['nickname'].strip().lower()
        
        # check nickname length
        if len(nickname) < 4:
            return render_template('error.html', message="Too short nickname!")
        
        session['nickname'] = nickname
        return redirect('/')
    
    return render_template('index.html')

    
@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if 'nickname' not in session:
        return redirect('/')
        
    if request.method == 'GET':
        return render_template('upload.html')
        
    try:
        image_file = request.files['image']
        fname = image_file.filename
        
        # check extension
        if fname[-4:] not in ['.jpg', '.png']:
            return render_template('error.html', message='This extension is not allowed')
        
        # upload file
        enc = hashlib.md5()
        enc.update(fname.encode())
        stored_filename = enc.hexdigest() + fname[-4:]
        
        image_path = "static/images/" + stored_filename
        image_file.save(image_path)
        
        image_infos = get_images_info()
        image_infos[image_file.filename] = image_path
        redis_server.set(name=session['nickname'], value=json.dumps(image_infos))
        
    except Exception as err:
        return render_template('error.html', message=str(err))
    
    return redirect('/')


@app.route('/rename', methods=['GET', 'POST'])
def rename():
    if 'nickname' not in session:
        return redirect('/')

    if request.method == 'GET':
        return render_template('rename.html')
    
    try:
        origin_fname = request.form['origin_filename'].encode()
        new_fname    = request.form['new_filename'].encode()
        
        raw = redis_server.get(name=session['nickname'])
        if raw != None:
            raw = raw.replace(origin_fname, new_fname)
            redis_server.set(name=session['nickname'], value=raw)
        else:
            return render_template('error.html', message="Not found uploaded file")
            
    except Exception as err:
        print(err)
        return render_template('error.html', message=str(err))

    return redirect('/')
    
    
@app.route('/delete', methods=['POST'])
def delete():
    if 'nickname' not in session:
        return redirect('/')

    try:
        image_infos = get_images_info()
        del image_infos[request.form['filename']]
        redis_server.set(name=session['nickname'], value=json.dumps(image_infos))
        
    except Exception as err:
        return render_template('error.html', message=str(err))
        
    return redirect('/')

    
@app.route('/flag')
def flag():
    if 'nickname' in session:
        if session['nickname'] == "SUPER_NICKNAME":
            return os.environ['FLAG']
            
    return render_template('error.html', message="NOoooooo")




if __name__ == '__main__':
    app.run('0.0.0.0', 80)
