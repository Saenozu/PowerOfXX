#include <stdio.h>
#include <unistd.h>
#include <string.h>

int main(){
        int idx;
        while(1){
                printf("what do you want?\n");
                menu();
                scanf("%d", &idx);
                switch(idx){
                        case 1:
                                cook();
                                break;
                        case 2:
                                eat();
                                break;
                        case 3:
                                dishwashing();
                                break;
                        default:
                                printf("nothing......\n");
                                break;
                }
        }
}

void menu(){
        printf("1. cook!\n");
        printf("2. eat\n");
        printf("3. dishwashing\n");
}

void cook(){